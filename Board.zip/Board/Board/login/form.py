from django import forms
from .models import doctors,contactlist

class ContactForm(forms.Form):
    full_name= forms.CharField()
    email_id=forms.EmailField()
    content=forms.CharField(widget=forms.Textarea)

    def clean_email_id(self,*args,**kwargs):  # form validation
        email_id=self.cleaned_data.get('email_id')
        print(email_id)
        qs=contactlist.objects.filter(email_id__iexact=email_id)
        if email_id.endswith(".edu"):
            raise forms.ValidationError("com email not accepted")
        elif qs.exists():
            raise forms.ValidationError("edu Email already used")
        return email_id

class ContactModelForm(forms.ModelForm):
    class Meta:
        model=contactlist
        fields =['full_name','email_id','content']

    def clean_email_id(self,*args,**kwargs):  # form validation
        email_id=self.cleaned_data.get('email_id')
        print(email_id)
        qs=contactlist.objects.filter(email_id=email_id)
        if qs.exists():
            raise forms.ValidationError("Email already used")
        if email_id.endswith(".edu"):
            raise forms.ValidationError("edu email not accepted")
        return email_id

class DoctorForm(forms.Form):
    name= forms.CharField()
    slug=forms.SlugField()
    description=forms.CharField(widget=forms.Textarea)

class DoctorModelForm(forms.ModelForm):
    class Meta:
        model=doctors
        fields=['user','name','slug','description']
