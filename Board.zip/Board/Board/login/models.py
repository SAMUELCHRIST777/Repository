from django.db import models
from django.contrib.auth.models import User
from django.conf import settings

# Create your models here.

User =  settings.AUTH_USER_MODEL
"""
class Board(models.Model):
    name=models.CharField(max_length=30,unique=True)
    description = models.CharField(max_length=100)

class Topic(models.Model):
    subject=models.CharField(max_length=255)
    last_updated=models.DateTimeField(auto_now_add=True)
    board= models.ForeignKey(Board,on_delete=models.CAS,related_name='topics')
    starter= models.Foreignkey(User,related_name='topics')

class Post(models.Model):
    message = models.TextField(max_length=4000)
    topic=models.ForeignKey(Topic,related_name='posts')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(null=True)
    create_by = models.ForeignKey(User,related_name='posts')
    updated_by = models.ForeignKey(User,related_name='+')
"""
class doctors(models.Model):
    user=models.ForeignKey(User,null=True,on_delete=models.SET_NULL)
    name = models.CharField(max_length=100,null=False,blank=False)
    slug = models.SlugField(unique=True)
    description=models.CharField(max_length=1000,null=False,blank=False)

    def get_absolute_path(self):
        return f"{self.slug}"

    def get_edit_path(self):
        return f"{self.get_absolute_path}/edit"

    def get_delete_path(self):
        return f"{self.get_absolute_path}/delete"

class contactlist(models.Model):
    user=models.ForeignKey(User,default=1,null=True,on_delete=models.SET_NULL)
    full_name = models.CharField(max_length=50,null=False,blank=False)
    email_id = models.EmailField(unique=True)
    content=models.CharField(max_length=100,null=False,blank=False)
    phone = models.CharField(max_length=10,null=False,blank=False)
