from django.contrib import admin

# Register your models here.
from .models import doctors,contactlist 

admin.site.register(doctors)
admin.site.register(contactlist)
