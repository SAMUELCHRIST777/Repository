from django.urls import path,re_path
from . import views
#dont repeat yourself = DRY

urlpatterns = [
        path('',views.login,name ="login"),
        path('about/',views.about,name ="about"),
        path('contact/',views.contact,name ="contact"),
        path('example/',views.example,name ="example"),
        path('doctor/',views.doctors_list_view,name ="doctor_detail"),
        path('doctor/<str:slug>/',views.doctor_detail,name ="doctor_detail"),
        path('doctor-new/',views.doctors_create_view,name ="doctor_create"),
        path('doctor-post/',views.doctors_post_view,name ="doctor_post"),
        path('doctor/<str:slug>/edit',views.doctors_update_view,name ="doctor_update"),
        path('doctor/<str:slug>/delete',views.doctors_delete_view,name ="doctor_delete"),

        #path('doctor_list',views.doctors_list_view,name ="doctor_list"),
        #re_path(r'^doctor/?P<id>\d+)/$',views.doctor_detail,name ="doctor_detail"),

]
