from django.contrib.auth.decorators import login_required
from django.contrib.admin.views.decorators import staff_member_required
from django.shortcuts import render,get_object_or_404
from django.http import HttpResponse,Http404
from django.template.loader import get_template
from .models import doctors,contactlist
from .form import ContactForm,DoctorForm,DoctorModelForm,ContactModelForm

def login(request):
    page_title='login'
    context = {'page_title':page_title}
    return render(request,'loginPage.html',context)
# Create your views here.

def about(request):
    return render(request,'Home_page.html',{'page_title':'About'})

#@login_required(login_url='/contact')
@staff_member_required
def contact(request):
    #form=ContactForm(request.POST or None)
    #if form.is_valid():
    #    print(form.cleaned_data)
    #    form = ContactForm()
    #context={
    #    'page_title':'Contact',
    #    'form':form
    #}
    #return render(request,'form.html',context)
    form=ContactForm(request.POST or None)
    if form.is_valid():
        print(form.cleaned_data)
        obj=contactlist.objects.create(**form.cleaned_data)
        form = ContactForm()
    print(form)
    template_name='form.html'
    context={
    'form':form
    }
    return render(request,template_name,context)

def example(request):
    context={'page_title':"example"}
    Template_name="Home_page.html"
    template_obj=get_template(Template_name)
    return HttpResponse(template_obj.render(context))

def doctor_detail(request,slug):
    print('Django says',request.method,request.path,request.user)
    #try:
    #    obj=doctors.objects.get(slug=slug)
    #except doctors.DoesNotExist:
        #obj=get_object_or_404(doctors,slug=slug)
    queryset = doctors.objects.filter(slug=slug)
    if queryset.count() == 0:
        raise Http404
    obj=queryset.first()
    Template_name='doctor.html'
    context ={'objects':obj}
    return render(request,Template_name,context)

def doctors_list_view(request):
    #list out objects
    #could be Search
    qs=doctors.objects.all()
    template_name='doctor_list.html'
    context={'object_list':qs}
    return render(request,template_name,context)

def doctors_create_view(request):
    #create objects
    #?use form
#    form=DoctorForm(request.POST or None)
#    if form.is_valid():
#        print(form.cleaned_data)
#        obj=doctors.objects.create(**form.cleaned_data)
#        form = DoctorForm()
    form=DoctorModelForm(request.POST or None)
    if form.is_valid():
        form.save()
        form = DoctorModelForm()
    template_name='form.html'
    context={
    'form':form
    }
    return render(request,template_name,context)

def doctors_detail_view(request):
    # already done in doctor_detail
    return render(request,template_name,context)

def doctors_post_view(request):
    #create objects
    #?use form
    template_name='doctor_post.html'
    context={'form':None}
    return render(request,template_name,context)

def doctors_update_view(request,slug):
    obj=get_object_or_404(doctors,slug=str(slug))
    form=DoctorModelForm(request.POST or None, instance=obj)
    if form.is_valid():
        form.save()
    elif not form.is_valid():
        form.errors
    template_name='form.html'
    context={"page_title" : f"Update {obj.name}",'form':form}
    return render(request,template_name,context)

def doctors_delete_view(request):
    template_name='doctor_delete.html'
    context={'form':None}
    return render(request,template_name,context)
